"""create_xyz_cluster - A simple python script to rbuild a xyz coordinate list of tatoms from a genetic algorithm output"""

__version__ = '1.0.0'
__author__ = 'Frank Doherty <fdoherty@umich.edu>'
__all__ = []
