create_xyz_cluster
==================


A simple python script to build a xyz coordinate list of atoms from a genetic algorithm output


Authors
-------

`create_xyz_cluster` was written by `Frank Doherty <fdoherty@umich.edu>`_.
