"""
Empty init file in case you choose a package besides PyTest such as Nose which may look for such a file
"""
